package com.jarvis.assistant

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference

/** On-device LLM (MediaPipe GenAI, .task model files). Loaded lazily on first use. */
object LlmEngine {
    private var llm: LlmInference? = null
    private var stamp = 0L

    @Synchronized
    fun generate(ctx: Context, prompt: String): String? {
        val f = Models.llmFile(ctx)
        if (!f.exists() || f.length() == 0L) return null
        return try {
            if (llm == null || stamp != f.lastModified()) {
                llm?.close()
                val opts = LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(f.absolutePath)
                    .setMaxTokens(768)
                    .build()
                llm = LlmInference.createFromOptions(ctx, opts)
                stamp = f.lastModified()
            }
            llm?.generateResponse(prompt)
        } catch (e: Throwable) {
            Log.e("Jarvis", "LLM failed", e)
            null
        }
    }

    @Synchronized
    fun reset() {
        try { llm?.close() } catch (e: Throwable) { }
        llm = null
    }
}
