package com.jarvis.assistant

import android.content.Context
import android.net.Uri
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Simple settings store. Cloud fallback is OFF by default. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    var cloudEnabled: Boolean
        get() = sp.getBoolean("cloud", false)
        set(v) { sp.edit().putBoolean("cloud", v).apply() }

    var apiKey: String
        get() = sp.getString("key", "") ?: ""
        set(v) { sp.edit().putString("key", v).apply() }

    var cloudModel: String
        get() = sp.getString("cmodel", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) { sp.edit().putString("cmodel", v).apply() }
}

/** Lets the service push log lines to the activity if it is visible. */
object Bus {
    @Volatile var sink: ((String) -> Unit)? = null
    fun post(s: String) { sink?.invoke(s) }
}

object Models {
    // Indian-English model first, US English as fallback.
    val VOSK_URLS = listOf(
        "https://alphacephei.com/vosk/models/vosk-model-small-en-in-0.4.zip",
        "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    )

    fun voskDir(ctx: Context) = File(ctx.filesDir, "vosk-model")
    fun llmFile(ctx: Context) = File(ctx.filesDir, "llm.task")
    fun voskReady(ctx: Context) = File(voskDir(ctx), "am").isDirectory
    fun llmReady(ctx: Context) = llmFile(ctx).let { it.exists() && it.length() > 0 }

    fun downloadVosk(ctx: Context, url: String, say: (String) -> Unit) {
        val zip = File(ctx.cacheDir, "vosk.zip")
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        if (c.responseCode != 200) throw RuntimeException("HTTP ${c.responseCode}")
        val total = c.contentLengthLong
        c.inputStream.use { input ->
            zip.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                var lastPct = -10
                var n = 0
                while (input.read(buf).also { n = it } > 0) {
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val pct = (done * 100 / total).toInt()
                        if (pct >= lastPct + 10) { lastPct = pct; say("Downloading speech model… $pct%") }
                    }
                }
            }
        }
        say("Unpacking…")
        val tmp = File(ctx.filesDir, "vosk-tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        ZipInputStream(zip.inputStream().buffered()).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val name = e.name.substringAfter('/', "")
                if (name.isNotEmpty()) {
                    val f = File(tmp, name)
                    if (!f.canonicalPath.startsWith(tmp.canonicalPath)) throw SecurityException("bad zip entry")
                    if (e.isDirectory) {
                        f.mkdirs()
                    } else {
                        f.parentFile?.mkdirs()
                        f.outputStream().use { zin.copyTo(it) }
                    }
                }
                e = zin.nextEntry
            }
        }
        zip.delete()
        val target = voskDir(ctx)
        target.deleteRecursively()
        if (!tmp.renameTo(target)) throw RuntimeException("Could not install model")
    }

    fun importLlm(ctx: Context, uri: Uri, say: (String) -> Unit) {
        val dest = llmFile(ctx)
        val input = ctx.contentResolver.openInputStream(uri) ?: throw RuntimeException("Cannot open file")
        input.use { ins ->
            dest.outputStream().use { out ->
                val buf = ByteArray(1 shl 20)
                var done = 0L
                var lastMb = 0L
                var n = 0
                while (ins.read(buf).also { n = it } > 0) {
                    out.write(buf, 0, n)
                    done += n
                    val mb = done shr 20
                    if (mb >= lastMb + 100) { lastMb = mb; say("Copying AI model… $mb MB") }
                }
            }
        }
    }
}
