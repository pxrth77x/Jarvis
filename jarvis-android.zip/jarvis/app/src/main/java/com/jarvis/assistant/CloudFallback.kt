package com.jarvis.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Optional Gemini fallback. Does nothing unless the user turned it on and added an API key. */
object CloudFallback {
    fun ask(prefs: Prefs, prompt: String): String? {
        if (!prefs.cloudEnabled || prefs.apiKey.isBlank()) return null
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${prefs.cloudModel}:generateContent")
            val c = url.openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 10000
            c.readTimeout = 30000
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", prefs.apiKey)
            val part = JSONObject().put("text", prompt)
            val content = JSONObject().put("parts", JSONArray().put(part))
            val body = JSONObject().put("contents", JSONArray().put(content))
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            if (c.responseCode !in 200..299) {
                null
            } else {
                val txt = c.inputStream.bufferedReader().readText()
                JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            }
        } catch (e: Exception) {
            null
        }
    }
}
