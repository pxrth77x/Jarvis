package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

/**
 * Turns a spoken sentence into a phone action.
 * 1) fast rules (instant, no AI needed)  2) on-device LLM  3) optional cloud fallback.
 */
class CommandRouter(context: Context) {
    private val ctx: Context = context.applicationContext
    private val prefs = Prefs(ctx)

    data class Act(val name: String, val arg: String = "")

    private val needAcc = "Turn on Jarvis in Accessibility settings first."

    fun handle(raw: String): String {
        val t = normalize(raw)
        if (t.isEmpty()) return "I didn't catch that."
        rule(t)?.let { return execute(it, false) }
        return askModels(raw.trim())
    }

    // ---------- 1. rules ----------

    private fun normalize(s: String): String {
        var t = s.lowercase().replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
        for (p in listOf("hey jarvis", "jarvis", "please", "can you", "could you", "would you")) {
            if (t.startsWith("$p ")) t = t.removePrefix("$p ").trim()
        }
        return t.removeSuffix(" please").trim()
    }

    private fun rule(t: String): Act? {
        when (t) {
            "home", "go home", "home screen", "go to home screen" -> return Act("home")
            "back", "go back" -> return Act("back")
            "recents", "recent apps", "show recent apps", "overview" -> return Act("recents")
            "notifications", "open notifications", "show notifications", "notification panel" -> return Act("notifications")
            "quick settings", "open quick settings" -> return Act("quick_settings")
            "lock", "lock screen", "lock the screen", "lock phone", "lock the phone" -> return Act("lock")
            "screenshot", "take screenshot", "take a screenshot" -> return Act("screenshot")
            "power menu" -> return Act("power_menu")
            "scroll down" -> return Act("scroll", "down")
            "scroll up" -> return Act("scroll", "up")
            "swipe left" -> return Act("scroll", "left")
            "swipe right" -> return Act("scroll", "right")
            "volume up", "louder", "turn it up" -> return Act("volume_up")
            "volume down", "quieter", "turn it down" -> return Act("volume_down")
            "mute", "silence" -> return Act("mute")
            "flashlight on", "torch on", "turn on flashlight", "turn on the flashlight", "turn on torch" -> return Act("flashlight", "on")
            "flashlight off", "torch off", "turn off flashlight", "turn off the flashlight", "turn off torch" -> return Act("flashlight", "off")
            "play", "pause", "resume", "play music", "pause music", "stop music" -> return Act("media", "play")
            "next song", "next track", "skip", "next" -> return Act("media", "next")
            "previous song", "previous track", "previous" -> return Act("media", "prev")
            "what time is it", "time", "what is the time" -> return Act("time")
            "what is the date", "date", "what day is it", "what is today" -> return Act("date")
            "what is on screen", "read screen", "read the screen" -> return Act("read_screen")
            "stop", "cancel", "never mind", "nevermind" -> return Act("say", "Okay.")
        }
        Regex("^(open|launch|start) (.+)$").find(t)?.let { return Act("open_app", it.groupValues[2]) }
        Regex("^(tap|click|press|select) (on )?(.+)$").find(t)?.let { return Act("tap", it.groupValues[3]) }
        Regex("^(type|write|enter) (.+)$").find(t)?.let { return Act("type", it.groupValues[2]) }
        Regex("^(search for|search|google|look up) (.+)$").find(t)?.let { return Act("web_search", it.groupValues[2]) }
        Regex("^(set )?volume (to )?(.+)$").find(t)?.let { m ->
            wordsToInt(m.groupValues[3])?.let { return Act("volume_set", it.coerceIn(0, 100).toString()) }
        }
        return null
    }

    private val units = mapOf(
        "zero" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6,
        "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12,
        "thirteen" to 13, "fourteen" to 14, "fifteen" to 15, "sixteen" to 16, "seventeen" to 17,
        "eighteen" to 18, "nineteen" to 19
    )
    private val tens = mapOf(
        "twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50,
        "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90
    )

    private fun wordsToInt(s: String): Int? {
        s.trim().toIntOrNull()?.let { return it }
        var total = 0
        var any = false
        for (w in s.trim().split(" ")) {
            when {
                units.containsKey(w) -> { total += units.getValue(w); any = true }
                tens.containsKey(w) -> { total += tens.getValue(w); any = true }
                w == "hundred" -> { total = if (total == 0) 100 else total * 100; any = true }
                w == "and" -> {}
                else -> return null
            }
        }
        return if (any) total else null
    }

    // ---------- 2/3. AI ----------

    private val allowed = setOf(
        "open_app", "home", "back", "recents", "notifications", "quick_settings", "lock", "screenshot",
        "power_menu", "scroll", "volume_up", "volume_down", "volume_set", "mute", "flashlight", "media",
        "tap", "type", "web_search", "say", "time", "date", "read_screen"
    )

    private fun buildPrompt(userText: String, screen: String): String = """
You are Jarvis, a voice assistant that controls an Android phone.
Reply with ONE JSON object and nothing else.
Actions:
{"action":"open_app","arg":"<app name>"}
{"action":"home"} {"action":"back"} {"action":"recents"} {"action":"notifications"}
{"action":"quick_settings"} {"action":"lock"} {"action":"screenshot"}
{"action":"scroll","arg":"up|down|left|right"}
{"action":"volume_up"} {"action":"volume_down"} {"action":"flashlight","arg":"on|off"}
{"action":"tap","arg":"<text visible on screen>"} {"action":"type","arg":"<text>"}
{"action":"web_search","arg":"<query>"}
{"action":"say","arg":"<short spoken answer>"}
Use "say" for questions, or when none of the other actions fit.
Text visible on screen: $screen
User said: "$userText"
JSON:
""".trimIndent()

    private fun parseAction(out: String?): Act? {
        if (out == null) return null
        val s = out.indexOf('{')
        val e = out.lastIndexOf('}')
        if (s < 0 || e <= s) return null
        return try {
            val j = JSONObject(out.substring(s, e + 1))
            val n = j.optString("action")
            if (n in allowed) Act(n, j.optString("arg")) else null
        } catch (ex: Exception) {
            null
        }
    }

    private fun askModels(raw: String): String {
        val screen = JarvisAccessibility.instance?.screenText()?.take(500).orEmpty()
        val prompt = buildPrompt(raw, screen)
        val local = LlmEngine.generate(ctx, prompt)
        parseAction(local)?.let { return execute(it, true) }
        val cloud = CloudFallback.ask(prefs, prompt)
        parseAction(cloud)?.let { return execute(it, true) }
        val text = (cloud ?: local)?.trim()
        if (!text.isNullOrEmpty()) return text.take(300)
        return "I didn't understand that. Add an on-device AI model in the app to handle open-ended requests."
    }

    // ---------- actions ----------

    private val risky = Regex("pay|send|buy|purchase|transfer|delete|remove|confirm|uninstall|reset|erase|order|donate|install")

    fun execute(a: Act, fromModel: Boolean): String {
        val acc = JarvisAccessibility.instance
        return when (a.name) {
            "open_app" -> openApp(a.arg)
            "home" -> global(AccessibilityService.GLOBAL_ACTION_HOME, "Going home.")
            "back" -> global(AccessibilityService.GLOBAL_ACTION_BACK, "Going back.")
            "recents" -> global(AccessibilityService.GLOBAL_ACTION_RECENTS, "Recent apps.")
            "notifications" -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Notifications.")
            "quick_settings" -> global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS, "Quick settings.")
            "lock" -> global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "Locking.")
            "screenshot" -> global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "Taking a screenshot.")
            "power_menu" -> global(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG, "Power menu.")
            "scroll" -> if (acc == null) needAcc else { acc.scroll(a.arg); "Scrolling ${a.arg}." }
            "tap" -> when {
                acc == null -> needAcc
                fromModel && risky.containsMatchIn(a.arg.lowercase()) -> "I won't tap \"${a.arg}\" on my own. Say it yourself: tap ${a.arg}."
                acc.tapText(a.arg) -> "Tapped ${a.arg}."
                else -> "I couldn't find ${a.arg} on screen."
            }
            "type" -> when {
                acc == null -> needAcc
                acc.typeText(a.arg) -> "Typed."
                else -> "Tap a text box first."
            }
            "read_screen" -> if (acc == null) needAcc else acc.screenText().ifBlank { "I can't see any text." }.take(300)
            "volume_up" -> adjust(AudioManager.ADJUST_RAISE, "Volume up.")
            "volume_down" -> adjust(AudioManager.ADJUST_LOWER, "Volume down.")
            "mute" -> adjust(AudioManager.ADJUST_MUTE, "Muted.")
            "volume_set" -> setVolume(a.arg.toIntOrNull() ?: 50)
            "flashlight" -> torch(a.arg != "off")
            "media" -> {
                val code = when (a.arg) {
                    "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                    "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                }
                mediaKey(code)
                "Okay."
            }
            "web_search" -> {
                val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, a.arg)
                if (startAct(i)) "Searching for ${a.arg}." else "I couldn't open a browser."
            }
            "time" -> "It's " + LocalTime.now().format(DateTimeFormatter.ofPattern("h:mm a")) + "."
            "date" -> "Today is " + LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM")) + "."
            "say" -> a.arg.ifBlank { "Okay." }
            else -> "I can't do that yet."
        }
    }

    private fun global(action: Int, msg: String): String {
        val acc = JarvisAccessibility.instance ?: return needAcc
        acc.global(action)
        return msg
    }

    private fun audio(): AudioManager = ctx.getSystemService(AudioManager::class.java)

    private fun adjust(dir: Int, msg: String): String {
        audio().adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        return msg
    }

    private fun setVolume(pct: Int): String {
        val am = audio()
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, pct.coerceIn(0, 100) * max / 100, AudioManager.FLAG_SHOW_UI)
        return "Volume $pct percent."
    }

    private fun mediaKey(code: Int) {
        val am = audio()
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun torch(on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.first {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            cm.setTorchMode(id, on)
            if (on) "Flashlight on." else "Flashlight off."
        } catch (e: Exception) {
            "I couldn't reach the flashlight."
        }
    }

    private fun startAct(i: Intent): Boolean {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val c: Context = JarvisAccessibility.instance ?: ctx
        return try { c.startActivity(i); true } catch (e: Exception) { false }
    }

    private fun settingsIntent(s: String): Intent? {
        if (!s.contains("setting") && s !in setOf("wifi", "wi fi", "bluetooth")) return null
        val action = when {
            "wifi" in s || "wi fi" in s -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" in s -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" in s || "brightness" in s -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" in s || "volume" in s -> Settings.ACTION_SOUND_SETTINGS
            "location" in s -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "battery" in s -> Intent.ACTION_POWER_USAGE_SUMMARY
            "airplane" in s -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return Intent(action)
    }

    private fun openApp(spoken: String): String {
        settingsIntent(spoken)?.let {
            return if (startAct(it)) "Opening settings." else "I couldn't open that."
        }
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val s = spoken.filter { it.isLetterOrDigit() }
        if (s.isEmpty()) return "Which app?"
        var bestScore = Int.MAX_VALUE
        var best: ResolveInfo? = null
        for (ri in pm.queryIntentActivities(launcher, 0)) {
            val label = ri.loadLabel(pm).toString().lowercase().filter { it.isLetterOrDigit() }
            if (label.isEmpty()) continue
            val score = when {
                label == s -> 0
                label.startsWith(s) || s.startsWith(label) -> 1
                label.contains(s) -> 2
                else -> {
                    val d = lev(label, s)
                    if (d <= maxOf(1, s.length / 4)) 3 + d else Int.MAX_VALUE
                }
            }
            if (score < bestScore) { bestScore = score; best = ri }
        }
        val ri = best ?: return "I couldn't find an app called $spoken."
        val i = pm.getLaunchIntentForPackage(ri.activityInfo.packageName) ?: return "I can't open that app."
        val name = ri.loadLabel(pm)
        return if (startAct(i)) "Opening $name." else "Android blocked that. Allow display over other apps in Jarvis."
    }

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }
}
