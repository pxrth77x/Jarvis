package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/** Setup screen: permissions, model downloads, settings, start/stop and a typed-command test box. */
class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var keyBox: EditText
    private lateinit var modelBox: EditText
    private val logLines = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad * 2, pad, pad)

        val title = TextView(this)
        title.text = "Jarvis"
        title.textSize = 28f
        root.addView(title)

        status = TextView(this)
        status.setPadding(0, pad, 0, pad)
        root.addView(status)

        addButton(root, "1 · Allow microphone & notifications") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        addButton(root, "2 · Download speech model (one time, ~40 MB)") { downloadSpeechModel() }
        addButton(root, "3 · Turn on Jarvis in Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton(root, "4 · Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        addButton(root, "5 · Pick on-device AI model (.task file, optional)") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            startActivityForResult(i, 42)
        }

        val cloud = Switch(this)
        cloud.text = "Cloud fallback (Gemini) - off by default"
        cloud.isChecked = prefs.cloudEnabled
        cloud.setOnCheckedChangeListener { _, on -> prefs.cloudEnabled = on }
        root.addView(cloud)

        keyBox = EditText(this)
        keyBox.hint = "Gemini API key (only used if cloud fallback is on)"
        keyBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        keyBox.setText(prefs.apiKey)
        root.addView(keyBox)

        modelBox = EditText(this)
        modelBox.hint = "Cloud model name"
        modelBox.setText(prefs.cloudModel)
        root.addView(modelBox)

        addButton(root, "▶  Start Jarvis") { startJarvis() }
        addButton(root, "■  Stop Jarvis") {
            startService(Intent(this@MainActivity, JarvisService::class.java).setAction("stop"))
            root.postDelayed({ refresh() }, 500)
        }

        val testBox = EditText(this)
        testBox.hint = "Type a command to test (e.g. open youtube)"
        root.addView(testBox)
        addButton(root, "Run command") {
            val text = testBox.text.toString()
            log("You: $text")
            Thread {
                val reply = try {
                    CommandRouter(applicationContext).handle(text)
                } catch (e: Exception) {
                    "Error: ${e.message}"
                }
                log("Jarvis: $reply")
            }.start()
        }

        logView = TextView(this)
        logView.typeface = android.graphics.Typeface.MONOSPACE
        logView.setPadding(0, pad, 0, 0)
        root.addView(logView)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun addButton(parent: LinearLayout, label: String, onClick: () -> Unit) {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        parent.addView(b)
    }

    private fun downloadSpeechModel() {
        Thread {
            var ok = false
            for (url in Models.VOSK_URLS) {
                try {
                    Models.downloadVosk(this, url) { log(it) }
                    ok = true
                    break
                } catch (e: Exception) {
                    log("Failed (${e.message}), trying next…")
                }
            }
            log(if (ok) "Speech model ready." else "Download failed. Check your internet connection.")
            runOnUiThread { refresh() }
        }.start()
    }

    private fun startJarvis() {
        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!micOk) { log("Allow the microphone first (step 1)."); return }
        if (!Models.voskReady(this)) { log("Download the speech model first (step 2)."); return }
        prefs.apiKey = keyBox.text.toString().trim()
        prefs.cloudModel = modelBox.text.toString().trim().ifEmpty { "gemini-2.5-flash" }
        startForegroundService(Intent(this, JarvisService::class.java))
        keyBox.postDelayed({ refresh() }, 800)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            Thread {
                try {
                    Models.importLlm(this, uri) { log(it) }
                    LlmEngine.reset()
                    log("AI model ready.")
                } catch (e: Exception) {
                    log("Import failed: ${e.message}")
                }
                runOnUiThread { refresh() }
            }.start()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        Bus.sink = { log(it) }
        refresh()
    }

    override fun onPause() {
        prefs.apiKey = keyBox.text.toString().trim()
        prefs.cloudModel = modelBox.text.toString().trim().ifEmpty { "gemini-2.5-flash" }
        Bus.sink = null
        super.onPause()
    }

    private fun mark(ok: Boolean) = if (ok) "✅" else "⬜"

    private fun refresh() {
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        status.text = listOf(
            "${mark(mic)} Microphone",
            "${mark(Models.voskReady(this))} Speech model",
            "${mark(JarvisAccessibility.instance != null)} Accessibility (phone control)",
            "${mark(Settings.canDrawOverlays(this))} Display over other apps",
            "${mark(Models.llmReady(this))} On-device AI model (optional; basic commands work without it)",
            "${mark(JarvisService.running)} Jarvis running"
        ).joinToString("\n")
    }

    private fun log(s: String) {
        runOnUiThread {
            logLines.add(s)
            while (logLines.size > 25) logLines.removeAt(0)
            logView.text = logLines.joinToString("\n")
        }
    }
}
