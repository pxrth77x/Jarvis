package com.jarvis.assistant

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Always-on listener. Say "Nothing" (wake word), a beep plays, then say your command.
 * Wake word and speech-to-text both run offline with Vosk.
 */
class JarvisService : Service() {

    companion object {
        @Volatile var running = false
    }

    @Volatile private var alive = false
    @Volatile private var busy = false
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var router: CommandRouter

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startInForeground()
        } catch (e: Exception) {
            Log.e("Jarvis", "Cannot start foreground", e)
            stopSelf()
            return START_NOT_STICKY
        }
        if (!alive) {
            alive = true
            running = true
            router = CommandRouter(applicationContext)
            tts = TextToSpeech(this) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = Locale.US
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(id: String?) {}
                        override fun onDone(id: String?) { busy = false }
                        @Deprecated("Deprecated in Java")
                        override fun onError(id: String?) { busy = false }
                    })
                    ttsReady = true
                }
            }
            Thread { loop() }.start()
        }
        return START_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, JarvisService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis is listening")
            .setContentText("Say \"Nothing\", then your command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    private fun beep() {
        try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 70).startTone(ToneGenerator.TONE_PROP_ACK, 150)
        } catch (e: Exception) { }
    }

    private fun speak(text: String) {
        Bus.post("Jarvis: $text")
        val t = tts
        if (!ttsReady || t == null || t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u") != TextToSpeech.SUCCESS) {
            busy = false
        }
    }

    private fun dispatch(text: String) {
        val cleaned = text.removePrefix("nothing").trim()
        if (cleaned.isEmpty()) return
        Bus.post("You: $cleaned")
        busy = true
        worker.execute {
            val reply = try {
                router.handle(cleaned)
            } catch (e: Exception) {
                Log.e("Jarvis", "command failed", e)
                "Something went wrong."
            }
            speak(reply)
        }
    }

    @SuppressLint("MissingPermission")
    private fun loop() {
        if (!Models.voskReady(this)) {
            Bus.post("Speech model missing. Download it in the app first.")
            stopSelf()
            return
        }
        var model: Model? = null
        var wake: Recognizer? = null
        var cmd: Recognizer? = null
        var rec: AudioRecord? = null
        try {
            LibVosk.setLogLevel(LogLevel.WARNINGS)
            model = Model(Models.voskDir(this).absolutePath)
            wake = Recognizer(model, 16000f, "[\"nothing\", \"[unk]\"]")
            cmd = Recognizer(model, 16000f)
            val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            rec = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 8192) * 2
            )
            rec.startRecording()
            Bus.post("Listening. Say \"Nothing\" then a command.")

            val buf = ByteArray(4096)
            var listening = false
            var deadline = 0L
            var wasBusy = false

            while (alive) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                if (busy) { wasBusy = true; continue }
                if (wasBusy) { wake.reset(); wasBusy = false }

                if (!listening) {
                    val heard = if (wake.acceptWaveForm(buf, n)) wake.result else wake.partialResult
                    if (heard.contains("nothing")) {
                        wake.reset()
                        cmd.reset()
                        listening = true
                        deadline = System.currentTimeMillis() + 8000
                        beep()
                    }
                } else {
                    var text: String? = null
                    if (cmd.acceptWaveForm(buf, n)) {
                        text = JSONObject(cmd.result).optString("text")
                    } else if (System.currentTimeMillis() > deadline) {
                        text = JSONObject(cmd.finalResult).optString("text")
                    }
                    if (text != null) {
                        listening = false
                        wake.reset()
                        if (text.isNotBlank()) dispatch(text)
                    }
                }
            }
        } catch (e: Throwable) {
            Log.e("Jarvis", "listen loop crashed", e)
            Bus.post("Listener error: ${e.message}")
        } finally {
            try { rec?.stop() } catch (e: Exception) { }
            rec?.release()
            wake?.close()
            cmd?.close()
            model?.close()
            alive = false
            running = false
            stopSelf()
        }
    }

    override fun onDestroy() {
        alive = false
        running = false
        tts?.shutdown()
        worker.shutdown()
        super.onDestroy()
    }
}
