# Jarvis for Android (no root)

Say **"Nothing"** → beep → say a command. Wake word and speech recognition run offline (Vosk).
Phone control uses an Accessibility Service (no root). An optional on-device LLM
(MediaPipe, `.task` file) handles open-ended requests. Cloud fallback is off by default.

## Build the APK (GitHub Actions)
1. Create a new GitHub repo and upload everything in this folder (including `.github`).
2. Open the **Actions** tab → "Build APK" → wait for the green tick.
3. Download the `jarvis-debug-apk` artifact, unzip, install `app-debug.apk`.

## First run
1. Allow mic + notifications. 2. Download speech model. 3. Turn on Accessibility.
   (Android 13+: if the switch is greyed out, open App info for Jarvis → ⋮ → "Allow restricted settings".)
4. Allow display over other apps (needed to open apps from voice). 5. Optional: pick a `.task` LLM
   (e.g. a Gemma 3 1B int4 MediaPipe model from Hugging Face "litert-community").
Then tap Start Jarvis.

## Commands that work without any AI model
open <app>, go home / back / recent apps, notifications, quick settings, lock screen, screenshot,
scroll up/down, swipe left/right, volume up/down/set volume to fifty, mute, flashlight on/off,
play / pause / next song, tap <text on screen>, type <text>, read screen, search for <query>,
what time is it, open wifi/bluetooth/display settings.
